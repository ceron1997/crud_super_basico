/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Cliente;
import modelo.Conexion;
import modelo.Familiar;

/**
 *
 * @author LENOVO
 */
public class FamiliarDao {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    public List verFamiliares(int idcliente) {
        //busca el cliente por nombre segun el texto en el campo de texto de seleccionar cliente
        List<Familiar> ListaCl = new ArrayList();

        String sql = "select * from familiar where id_cliente = ?;";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, idcliente);
            rs = ps.executeQuery();

            while (rs.next()) {
                Familiar objFamiliar = new Familiar();
                objFamiliar.setIdfamiliar(rs.getInt("id"));
                objFamiliar.setNombre(rs.getString("nombre"));
                objFamiliar.setEdad(rs.getInt("edad"));
                objFamiliar.setParentesco(rs.getString("parentesco"));
                ListaCl.add(objFamiliar);

            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e.toString());
            JOptionPane.showMessageDialog(null, " " + e);

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClienteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ListaCl;

    }

    public void eliminarFamiliar(int idfamiliar) {

        String sql = "delete from familiar where id = ?;";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, idfamiliar);
            ps.executeUpdate();
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.toString());
        }

    }

    public void guardarFamiliar(DefaultTableModel model, int idcliente) {
        try {
            // 1. Obtener los datos del JTable a través del modelo de datos.

            int rowCount = model.getRowCount();
               con = cn.getConnection();
            // 3. Ejecutar la sentencia SQL para insertar los datos en la base de datos.
            try (PreparedStatement pstmt = con.prepareStatement("replace INTO familiar (nombre, edad, parentesco, id_cliente) VALUES (?, ?, ?, ?)")) {
                // 3. Ejecutar la sentencia SQL para insertar los datos en la base de datos.
                for (int i = 0; i < rowCount; i++) {
                    pstmt.setString(1, model.getValueAt(i, 1).toString());
                    pstmt.setString(2, model.getValueAt(i, 2).toString());
                    pstmt.setString(3, model.getValueAt(i, 3).toString());
                    pstmt.setInt(4, idcliente);
                 
                    pstmt.executeUpdate();
                }
                // 4. Cerrar la conexión a la base de datos.
            }
            con.close();

            JOptionPane.showMessageDialog(null, "Los datos se han guardado correctamente en la base de datos.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al guardar los datos en la base de datos:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FamiliarDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}

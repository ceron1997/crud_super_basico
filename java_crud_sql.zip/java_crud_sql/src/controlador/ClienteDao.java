/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modelo.Cliente;
import modelo.Conexion;

public class ClienteDao {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    public String[] VerElcliente(int idcliente) {
        //busca el cliente poe numero de id   
        String cliente[] = new String[7];
        String sql = "select * from cliente where id = ?;";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, idcliente);
            rs = ps.executeQuery();
            while (rs.next()) {
                cliente[0] = rs.getString("nombre");
                cliente[1] = rs.getString("a_experiencia");
                cliente[2] = rs.getString("f_nacimiento");
                cliente[3] = rs.getString("departamento");
                cliente[4] = rs.getString("municipio");
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e.toString());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClienteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cliente;

    }

    public void RegistrarCliente(Cliente objCliente) throws ClassNotFoundException {
        // registra la venta para factura y ccf 

        String sql = "replace INTO `cliente` (id,  `nombre`, `a_experiencia`, `f_nacimiento`, `departamento`, `municipio`) VALUES (?,?,?,?,?,?)";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, objCliente.getIdcliente());
            ps.setString(2, objCliente.getNombre());
            ps.setInt(3, objCliente.getA_experiencia());
            ps.setString(4, objCliente.getF_nacimiento());
            ps.setString(5, objCliente.getDepartamento());
            ps.setString(6, objCliente.getMunicipio());

            ps.execute();
            con.close();
            //  JOptionPane.showMessageDialog(null, "Operación realizada correctamente");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    """
                    ha ocurrido un error en la insercion
                   
                    o """ + e, "Error ", JOptionPane.ERROR_MESSAGE);
            System.out.println("" + e);

        }
    }

    
    
    
      public void eliminarCliente(int idcliente) {

        String sql = "delete from cliente where id = ?;";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, idcliente);
            ps.executeUpdate();
            
                JOptionPane.showMessageDialog(null, "Los datos se han borrado correctamente de la base de datos.");
      
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.toString());
        }

    }

}

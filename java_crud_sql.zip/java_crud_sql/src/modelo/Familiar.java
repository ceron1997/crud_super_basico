/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author LENOVO
 */
public class Familiar {
    private int edad = 0, idfamiliar= 0;
    private String nombre, parentesco;

    public Familiar(String nombre, String parentesco, int edad , int idfamiliar) {
        this.nombre = nombre;
        this.parentesco = parentesco;
        this.edad = edad;
        this.idfamiliar = idfamiliar;
    }

    public Familiar() {
    }

    public int getIdfamiliar() {
        return idfamiliar;
    }

    public void setIdfamiliar(int idfamiliar) {
        this.idfamiliar = idfamiliar;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getParentesco() {
        return parentesco;
    }

    public void setParentesco(String parentesco) {
        this.parentesco = parentesco;
    }
    
    
    
    
}

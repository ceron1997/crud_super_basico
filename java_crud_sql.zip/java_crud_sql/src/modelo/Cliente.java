/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author LENOVO
 */
public class Cliente {

    private String nombre, f_nacimiento, departamento, municipio;
    private int idcliente = 0, a_experiencia = 0;

    public Cliente() {
        
    }

    public Cliente(String nombre, String f_nacimiento, int idcliente, int a_experiencia, String departamento, String municipio) {
        this.nombre = nombre;
        this.f_nacimiento = f_nacimiento;
        this.idcliente = idcliente ;
        this.a_experiencia = a_experiencia;
        this.departamento = departamento ;  
        this.municipio = municipio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getF_nacimiento() {
        return f_nacimiento;
    }

    public void setF_nacimiento(String f_nacimiento) {
        this.f_nacimiento = f_nacimiento;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public int getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(int idcliente) {
        this.idcliente = idcliente;
    }

    public int getA_experiencia() {
        return a_experiencia;
    }

    public void setA_experiencia(int a_experiencia) {
        this.a_experiencia = a_experiencia;
    }

 
    

}
